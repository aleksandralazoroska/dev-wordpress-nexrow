=== Plugin Name ===
Contributors: ntech-technologies
Donate link: http://ntechcorporate.com/Company/Testimonial-Slider-Pro
Tags: Testimonial, Testimonials, Testimonials Manager, Testimonials Slider,responsive slider,testimonial rotator,sliders,content slider,Sliders,Testimonial Slider,Testimonials rotator,best, super, top, responsive
Requires at least: 2.0.2
Tested up to: 4.1
Stable tag: 2.9.5

Best Responsive Testimonials slider. Manage and display testimonials for your blog, product or service.

== Description ==

Best Responsive Testimonials slider. Testimonials Slider is a WordPress plugin which is inspired from a bxslider. display testimonials for your blog, product or service. Automatically rotate testimonials in your sidebar. create a list of testimonials page.

This is without doubt the best testimonial plugin for WordPress, it is simple but powerful and flexible.


= ADD AND EDIT TESTIMONIALS EASILY =

To add a new testimonials, just enter the Name, Website and Website URL as well as the full testimonial.

You can then view all your testimonials in a screen that is pretty similar to how you manage WordPress comments, and choose to Edit or Delete testimonials.

= DISPLAY FULL TESTIMONIALS PAGE =

All your testimonials can be displayed according to order on a full page. All you need to do is paste the following code in any WordPress page where you want your 

ShortCode

For Slider:

	[show_testimonials]

For Full page

	[show_testimonials type='full']

= If you think, that you found a bug in our Testimonials Slider plugin or have any question contact us at arpit.h.ntech@gmail.com. =

== Installation ==

1. Upload testimonialslider folder to the /wp-content/plugins/ directory
2. Activate the plugin through the Plugins menu in WordPress
3. Now you are done. Enjoy the plugin!!!

== Frequently Asked Questions ==

Yet  to Come!!!

== Screenshots ==
1. Add/Edit Testimonial Post.
2. Display Testimonial Slider
3. Display List of Testimonials Page.
4. Testimonial Settings Page

5. Testimonial Slider Pro Settings Page
6. Testimonial Slider Pro Widget Options
7. Testimonial Slider Pro Grid View
== Changelog ==


= 2.9.4 =
* Minor Bug Fixes

= 2.9.4 =
* Fixes Shortcode Issue

= 2.9.3 =
* Minor Bug Fixes

= 2.9.2 =
* Minor Bug Fixes

= 2.9.1 =
* Minor Bug Fixes

= 2.9 =
* Minor Bug Fixes

= 2.8 =
* Minor Bug Fixes

= 2.7 =
* Bug Fixes
* add additional features in Setting Page

= 2.6 =
* Bug Fixes

= 2.5 =
* Add new Setting parameters
* change mode, speed, Controls,pager from setting page
* layout changes
* Bug Fixes

= 2.0 =
* Add Setting Page
* change mode, speed, Controls from setting page
* layout changes
* Bug Fixes

= 1.0 =
* First Version.
